<template>
  <div>我是团购订单内容</div>
</template>

<script>
export default {

}
</script>

<style>

</style>