const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  productionSourceMap: false,
  // 关闭eslint
  lintOnSave: false,
  transpileDependencies: true,
  // 代理跨域
  // 服务器之间不存在跨域问题， 浏览器之间才存在跨域问题，需要一个代理服务器来在前后端之间进行代理
  devServer: {
    proxy: {
      '/api': {
        // 你要获取数据的服务器的ip地址
        // target: 'http://39.98.123.211',
        target: 'http://gmall-h5-api.atguigu.cn',
        // pathRewrite: { '^/api': '' },
      },
    },
  },
})
