1.编程式导航路由跳转到当前路由(参数不变), 多次执行会抛出NavigationDuplicated的警告错误?
注意:编程式导航（push|replace）才会有这种情况的异常，声明式导航是没有这种问题，因为声明式导航内部已经解决这种问题。
这种异常，对于程序没有任何影响的。
为什么会出现这种现象:
由于vue-router最新版本3.5.2，引入了promise，当传递参数多次且重复，会抛出异常，因此出现上面现象,
第一种解决方案：是给push函数，传入相应的成功的回调与失败的回调
第一种解决方案可以暂时解决当前问题，但是以后再用push|replace还是会出现类似现象，因此我们需要从‘根’治病；


1.3通过底部的代码，可以实现解决错误
      this.$router.push({
        name: "search",
        params: {
          keyword: this.keyword,
        },
        query: {
          k: this.keyword.toUpperCase(),
        },
      },()=>{},()=>{});
这种写法治标不治本，将来在别的组件中push|replace，编程式导航还是会有类似的错误

1.4
this:当前组件实例
<!-- this.$router是VueRouter类的实例对象 -->
this.$router属性：当前的这个属性，属性值是VueRouter类的一个实例，当在入口文件注册路由的时候，给组件实例添加$router|$route属性
push：VueRouter类的一个实例·


function VueRouter(){

}
<!-- 原型对象的方法 -->
VueRouter.prototype.push=function(){
    //函数的上下文为VueRouter类的一个实例
}
let $router = new VueRouter();
$router.push(xxx)


2.Home模块组件拆分
--先把静态页面完成
--拆分出静态组件
--获取服务器的数据进行展示
--动态业务


3.三级联动组件完成
---由于三级组件，在Home、Search、Detail，把三级联动注册为全局组件
好处：只需要注册一次，就可以在项目任意地方使用


4:完成其余静态组件
HTML+CSS+图片资源----信息【结构、样式、图片资源】


5：POSTMAN测试接口

--经过postman工具测试，接口没问题
--如果服务器返回的数据code字段200，代表服务完器返回数据成功
--整个项目，接口前缀都有/api字眼

6.axios二次封装
XMLHttpRequest、fetch、JQ、axios
6.1为什么需要进行二次封axios
请求拦截器，响应拦截器：请求拦截器，可以在发请求之前可以处理一些业务、响应拦截器，当服务器数据返回以后，可以处理一些事情

6.2在项目当中经常有API【axios】
接口当中：路径都带有/api
baseURL:"/api"

6.3axios不熟悉的话可以查看git|NPM关于axios的文档

7.接口统一管理

项目很小：完全可以在组件的生命周期函数中发请求

项目大：axios.get("xxx")

7.1跨域问题
什么是跨域、协议、域名、端口号不同请求，称之为跨域
http://localhost:8080/#/home  ---前端项目本地服务器
http://39.98.123.211          ---后台服务器

JSONP、cors、代理


8:nprogress进度条的使用

start：进度条开始
done：进度条结束
进度条颜色可以修改的，需要修改人家的样式

9.1vuex是什么？
vuex是官方提供的一个插件，状态管理库，集中式管理项目组件共用的数据
切记，并不是全部的项目都需要vuex，项目大组件多，数据多，数据维护很费劲，需要vuex

state，
mutations
actions，
getters，
modules

9.2vuex基本使用

9.3vuex实现模块式开发
如果项目过大,组件过多,接口也很多,可以让Vuex实现模块式开发
模拟state存储数据

{
  home:{},
  search:{}
}



10:完成TypeNav三级联动展示数据业务


[
  {
    id:1,
    name:"电子书",
    child:[
      {id:2,name:"洗眼液",child:[]},
      {id:3,name:"洗眼液2"},
    ]
  }
]

