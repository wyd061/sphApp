复习：
1）商品分类的三级列表由静态转变为动态形式【获取服务器数据：解决跨域问题】
2）函数防抖与节流【面试频率很好】
3）路由跳转：声明式导航|编程式导航
编程式导航解决这个问题：自定义属性


1)开发Search模块中的TypeNav商品分类菜单（过度动画效果）

过渡动画：前提组件|元素务必要有v-if|v-show指令才可以进行过渡动画

2）对商品分类三级列表优化
在App根组件当中发请求【根组件mounted】执行一次

3）合并params与query参数？

4)开发Home首页中的ListContainer组件和Floor组件？
mock数据（模拟）    需要下载一个插件mockjs

使用步骤：
1）在项目中的src文件夹中创建mock文件夹
2）第二步准备JSON数据(mock文件夹中创建相应的JSON文件)--格式化一下，别留有空格（跑不起来的）
3）把mock数据需要的图片放到public文件夹中【public文件夹在打包的时候，会把相应的资源原封不动的打包到dist文件夹
4）创建mockSever.js通过mock.js插件实现模拟数据
5)mockServer.js文件在入口文件中引入（至少需要执行一次，才能模拟数据）


5)ListContainer组件开发重点

安装Swiper插件：cnpm i --save swiper@5