1）个人中心完成
面试的时候：是否封装过组件、分页器、日历
个人中心当中：分页器

2）全局守卫
未登录访问：、trade|pay|paysuccess|center跳转到登录页面


3）路由独享守卫
只有购物车界面才能跳到交易页面
只有从交易页面才能跳到支付页面
只有从支付页面才能跳转到支付成功页面


4）图片懒加载
http://www.npmjs.com/package/vue-lazyload
自定义插件：


5)vee-validate基本使用
第一步：插件安装与引入
cnpm i vee-validate@2 --save 安装的插件安装 2版本的
import VeeValidate from 'vee-validate'
import zh_CN from 'vee-validate/dist/locale/zh_CN'
Vue.use(VeeValidate)


第二步：提示信息
VeeValidate.Validator.localize('zh_CN', {
    messages: {
        ...zh_CN.messages,
        is: (field) => `$(field)必须与密码相同`//修改内置规则得message，让密码和确认密码相同
    },
    attributes: {
        phone: '手机号',
        code: '验证码',
        password: "密码",
        password1: "确认密码",
        isCheck: "协议"
    }
})

第三步：基本使用
        <label>手机号:</label>
        <input
          placeholder="请输入你的手机号"
          v-model="phone"
          name="phone"
          v-validate="{ required: true, regex: /^1\d{10}$/ }"
          :class="{ invalid: errors.has('phone') }"
        />
        <span class="error-msg">{{ errors.first("phone") }}</span>

const success = await this.$validator.validateAll();//全部表单验证

VeeValidate.Validator.extend('agree',{
    validate:value=>{
        return value
    },
    getMessage:field=>field+"必须同意"
})



6)路由懒加载

7)打包上线
7.1打包 npm run build
项目打包后，代码都是压缩加密的
map是未加密的代码，可以准确输出哪一行出错
vue.config.js配置
productionSourceMap：false

7.2购买云服务器